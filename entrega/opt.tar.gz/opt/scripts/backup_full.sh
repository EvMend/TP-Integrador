#!/bin/bash

if [ "$1" = "-help" ]; then
    echo "Uso:"
    echo "$0 <origen> <destino>"
    echo "Ejemplo:"
    echo "$0 /var/log /backup_dir"
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: cantidad de argumentos incorrecta."
    echo "Use $0 -help"
    exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
    echo "Error: directorio origen no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: directorio destino no existe."
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: el sistema de archivos destino no esta montado."
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")

tar -czf "${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"

echo "Backup completado: ${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"
