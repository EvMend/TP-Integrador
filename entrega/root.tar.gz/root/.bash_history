history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname TPServer
cat /etc/hostname
hostname
nano /etc/hostname
printf "TPServer




echo TPServer /etc/hostname
clear
echo TPServer /etc/hostname 
cat /etc/hostname
hostname TPServer
cat /etc/hostname
loadkeys us
printf TPServer 
vi /etc/hostname
vi /etc/hostname
clear
cat /etc/hostname
exit
hostname
vi /etc/hostname
vi /etc/hostname
cat / etc/hostname
cat /etc/hostname
rm -f /etc/hostnameswp
vi /etc/hostname
vi /etc/hostname
clear
cat /etc/hostname
hostname
exit
cat /root/bashrc
cat /root/.bashrc
cat / etc/hosts
cat /etc/hosts
hostnamectl
clear
hostnamectl
cat /proc/sys/kernel/hostname
uname -n
locate
cat /etc/default/keyboard
loadkeys us
dpkg-reconfigure keyboard-configuration
reboot
echo hello > /tmp/test
cat /tmp/test
clear
ping -c 4 8.8.8.8
ping -c 4 google.com
cat /etc/os-release
ls -lah/root
ls -lah /root
tar -xzf /root/Material_Adictional_TPVMCA.tar.gz -C /root
ls -lah /root
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls -lah /root
find /root -type f
clear
find /root -type f
~~find /root -name "*.php" -o name "*.png" -o name "*.sql" -o name "*.pub" -o name "id_*"
~~find /root -name "*.php" -o name "*.png" -o name "*.sql" -o name "*.pub" -o name "id_*"
clear
~~find /root -name "*.php" -o name "*.png" -o name "*.sql" -o name "*.pub" -o name "id_*"
ls /root
clear
find /root -name "index.php"
find /root -name "logo.png"
find /root -name "db.sql"
cat /etc/apt/sources.list
cp /etc/apt/sources.list /etc/apt/sources.list.bak
vi /etc/apt/sources.list
apt upgrade
apt upgrade -y
apt full upgrade -y
reboot
cat /etc/os-releases
cat /etc/os-release
vi /etc/apt/sources.list
cat /etc/os-release
reboot
apt update
apt upgrade -y
apt full upgrade -y
apt full-upgrade -y
reboot
ls 
clear
apt update
apt install apache2 php libapache2-mod-php -y
apache2 -v
php -v
systemctl enable apache2
systemctl start apache2
systemctl status apache2
ls -l /root
ls -lah /root/Material_Adicional_TPVMCA
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -l /var/www/html
curl http://localhost
ls -l /var/www/html
rm /var/www/html/index.html
systemctl restart apache2
systemctl status apache2
php -l /var/www/html/index.php
head -50 /var/www/html/index.php
tail -30 /var/log/apache2/error.log
apt install php-mysqli -y
systemctl restart apache2
php -m | grep mysqli
head -50 /var/www/html/index.php
tail -30 /var/log/apache2/error.log
clear
head -50 /var/www/html/index.php
tail -30 /var/log/apache2/error.log
apt install mariadb-server -y
systemctl enable mariadb
systemctl start mariadb
systemctl status mariadb
mysql -u root
head -50 /root/Material_Adicional_TPVMCA/db.sql
mysql -u root < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root
clear
mysql -u root
ip addr
ip route
cat /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking
ip addr
ip route
mkdir -p /root/.ssh
chmod 700 /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
nano /etc/ssh/sshd_config
systemctl restart ssh
head -5 /root/Material_Adicional_TPVMCA/clave_privada.txt
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
systemctl restart ssh
systemctl restart ssh
cat /root/Material_Adicional_TPVMCA/clave_privada.txt
ssh-keygen -l -f /root/Material_Adicional_TPVMCA/clave_privada.txt
cat /root/Material_Adicional_TPVMCA/clave_publica.pub
cat /root/.ssh/authorized_keys
ls -ld /root/.ssh
ls -l /root/.ssh/authorized_keys
grep -E "PubkeyAuthentication|AuthorizedKeysFile|PermitRootLogin" /etc/ssh/sshd_config
grep PasswordAuthentication /etc/ssh/sshd_config
grep PasswordAuthentication /etc/ssh/sshd_config
base64 -w 0 /root/Material_Adicional_TPVMCA/clave_privada.txt
ssh -Tvvv localhost
ssh-keygen -y -f /root/Material_Adicional_TPVMCA/clave_privada.txt
cat /root/Material_Adicional_TPVMCA/clave_publica.pub
hostnamectl
clear
cat /root/Material_Adicional_TPVMCA/clave_privada.txt
clear
cat /root/Material_Adicional_TPVMCA/clave_privada.txt
base64 -w 0 /root/Material_Adicional_TPVMCA/clave_privada.txt > /root/key.b64
cat /root/key.b64
clear
systemctl status ssh
nano /etc/ssh/sshd_config
exit
cat /root/Material_Adicional_TPVMCA/clave_privada.txt
wc -l /root/Material_Adicional_TPVMCA/clave_privada.txt
sed -n '10p' /root/Material_Adicional_TPVMCA/clave_privada.txt
nano /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
clear
grep "PermitRootLogin" /etc/ssh/sshd_config
grep "PasswordAuthentication" /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
apt install nano -y
nano /etc/ssh/sshd_config
grep -E "PermitRootLogin|PasswordAuthentication" /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
systemctl restart ssh
apt update
cat /etc/os-release
clear
apt full-upgrade -y
cat /etc/apt/sourceslist
cat /etc/apt/sources.list
grep -R bullseye /etc/apt/
ls -l /etc/apt
find /etc/apt -type f
cat /etc/apt/sources.list
apt update
apt-cache policy | head -20
vi /etc/apt/sources.list
apt install openssh-server -y
ping -c 4 deb.debian.org
cat /etc/apt/sources.list
cat /etc/os-release
cat /etc/os-release uname -a
apt update
apt policy openssh-server
cat /etc/resolv.conf
nano /etc/apt/sources.list
nano /etc/apt/sources.list
cat /etc/apt/sources.list
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt clean
apt update
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
apt full-upgrade -y
cat /etc/os-release
apt install openssh-server -y
systemctl enable ssh
systemctl start ssh
systemctl status ssh
ip add

hostname -I
passwd root
systemctl status ssh
su -
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
blkid /dev/sdc1
blkid /dev/sdc2
ls -l /var/www/html
mv /var/www/html/index.php /www_dir/
mv /var/www/html/logo.png /www_dir/
ls -l /www_dir
/var/www/html
nano /etc/fstab
umount /www_dir
umount /backup_dir
mount -a
df -h
systemctl daemon-reload
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
root@TPServer:~# systemctl daemon-reload
root@TPServer:~# grep DocumentRoot /etc/apache2/sites-available/000-default.conf
        DocumentRoot /var/www/html
root@TPServer:~#
nano /etc/apache2/sites-available/000-default.conf
grep -n "/var/www" /etc/apache2/apache2.conf
nano /etc/apache2/apache2.conf
systemctl restart apache2
systemctl status apache2 --no-pager
cat /proc/partitions > /opt/particion
ls -l /opt/particion
systemctl status apache2 --no-pager
ls -l /opt/particion
clear
systemctl status apache2 --no-pager
ls -l /opt/particion
reboot
